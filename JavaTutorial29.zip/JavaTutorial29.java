import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.io.FileNotFoundException;

class JavaTutorial29{


    public static void main(String[] args){

 	File myfile = new File("example.txt");

    try{
      PrintWriter pw = new PrintWriter(myfile);

      int number = 100;
      pw.println("Hello World " + 100);
      pw.println("I am handsome");
      pw.println("Hello File");

      pw.close();

    }catch(IOException ex){
      System.out.println("Error %s ",ex);
    }


    try{
      Scanner scan = new Scanner(myfile);

      String name = scan.nextLine();
      String age = scan.nextLine();
      String word = scan.nextLine();

      System.out.println(name);
      System.out.println(age);
      System.out.println(word);

      scan.close();

    }catch(FileNotFoundException ex){
      System.out.println("Error %s ",ex);
    }





    }


}