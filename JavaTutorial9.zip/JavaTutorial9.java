class JavaTutorial9{

	public static void main(String[] args){

	/*
	PEMDAS

	PARENTHESIS
	EXPONENTS
	MULTIPLICATION
	DIVISION
	ADDITION
	SUBTRACTION


	*/
	
	double result = (1+1+2.5) * 7 - 8 / 2;

	System.out.println("The value of result is "+result);

	} 
}