public class Animal{

  public void SaySomething(){
    System.out.println("I am an animal");
  }

}