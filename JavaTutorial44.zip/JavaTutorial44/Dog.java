public class Dog extends Animal{
  
  @Override
  public void SaySomething(){
    System.out.println("WOOF WOOF!!!");
  } 
  
}