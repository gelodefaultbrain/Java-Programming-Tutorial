class JavaTutorial44{


    public static void main(String[] args){
   
 
    Animal[] anim = new Animal[2];
    anim[0] = new Dog();
    anim[1] = new Bird();

    for(int i =0; i < anim.length; i++)
    {
       anim[i].SaySomething();
    }
    



    }


}