public class Bird extends Animal{
  
  @Override
  public void SaySomething(){
    System.out.println("Tweet Tweet!!!");
  }


}