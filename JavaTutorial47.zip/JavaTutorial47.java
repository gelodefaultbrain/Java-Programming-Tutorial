import java.util.Random;

class JavaTutorial47{


    public static void main(String[] args){

    Random generator = new Random();
    int number = generator.nextInt(10) + 1;
    System.out.println(number);

    number = generator.nextInt(10)+1;
    System.out.println(number);

    number = generator.nextInt(10)+1;
    System.out.println(number);

    }


}