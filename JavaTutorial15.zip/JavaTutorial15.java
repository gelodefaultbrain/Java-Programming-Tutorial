class JavaTutorial15{

	public static void main(String[] args){

    int x =2;
    int y =10;

    if( (x < y || y > x) && x > 20  )
    {

    	System.out.println("TRUE");
    }else
    {
    	System.out.println("FALSE");
    }


	} 
}