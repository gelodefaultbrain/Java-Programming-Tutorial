class JavaTutorial5{

	public static void main(String[] args){
		/*
          int - 100
          char -'A'
          boolean - ture , false
		  float - 1.1234567 #hanggang 7 digits lang after decimal point
		  double - 13.123456789012345 #hanggang 15 digits lang after decimal point
		  long - 123456789101112

		*/
   
      int number = 100; // %i or %d
      char letter = 'A'; // %c
      boolean condition = true; //%b
      double dl = 3.14; //%f
      float fl = 1.2f; //%f //put f to let java know na float yan cause in default numbers with decimal places are considered double in java
      long l = 12345678910L; //%d

      //please add backslash n , plugin won't display backslash :(
      System.out.printf("Number is %d ",number);
      System.out.printf("Character is %c ",letter);
      System.out.printf("Boolean is %b ",condition);
      System.out.printf("Double is %.4f ",dl);
      System.out.printf("Float is %.2f ",fl);
      System.out.printf("Long is %d ",l);


      System.out.printf("Value of number is %d and letter is %c",number,letter);


     
 

	} 
}