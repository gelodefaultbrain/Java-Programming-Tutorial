class JavaTutorial10{

	public static void main(String[] args){

	double cel;
	double faren = 40.2;

	cel = (faren - 32) * 5 / 9 //PEMDAS
	//faren = (cel * 9 / 5) + 32;

	System.out.println("The value of cel is "+cel);

	} 
}