
class JavaTutorial18{

     public static void main(String[] args){

       int max = 10;

       int counter;

       for(counter=0; counter < max; counter++)
       {
     	 System.out.println("Gels "+counter);
       }
 


	} 
}