import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

class JavaTutorial48{

    public static final int width = 500;
     public static final int height = 500;

    public static void main(String[] args){

     JButton button = new JButton("Here");
     JFrame mywindow = new JFrame("Title");
     mywindow.setSize(width,height);
     JLabel mylabel = new JLabel("Don't Click");


     mywindow.getContentPane().add(button);
     mywindow.getContentPane().add(mylabel);
     button.setSize(200,20);
     button.setLocation(50,50);

     mywindow.setVisible(true);



    }


}