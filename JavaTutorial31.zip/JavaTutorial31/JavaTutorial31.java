class JavaTutorial31{


    public static void main(String[] args){

    
    //Making an instance of an Object of type Dog
    Dog myDog = new Dog();
    myDog.breed = "Askal";

    Dog mydog1 = new Dog();
    mydog1.breed = "Pitbull";

    System.out.println(myDog.breed);
    System.out.println(mydog1.breed);



    }


}