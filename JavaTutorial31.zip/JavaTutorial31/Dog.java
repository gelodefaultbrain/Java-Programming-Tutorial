public class Dog{

   //Fields or Attributes , Katangian

   /*
   It's better for the attributes to be private
	pero pano natin ma-access yung attributes?
	Watch! on the tutorial about Getters & Setters (Java Tutorial #32)
  In the next tutorial!
  */
   public String breed;
   public String size;
   public int age;
   public String color;

   public Dog(){//Constructor

   }

   public void Eat(){
     System.out.println("Dog is Eating");
   }

    public void Sleep(){
     System.out.println("Dog is sleeping");
   }

    public void Sit(){
     System.out.println("Dog is sitting");
   }

    public void Run(){
     System.out.println("Dog is running");
   }


}