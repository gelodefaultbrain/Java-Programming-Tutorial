
class JavaTutorial23{

     public static void main(String[] args){

 	 
 	 int[][] array ={
      {4,1,3,7,9},
      {6,5,8,11,2},
      {12,14,17,20,0}
 	 };

     System.out.println(array[2][0]);//array[row][column]

	} 
}