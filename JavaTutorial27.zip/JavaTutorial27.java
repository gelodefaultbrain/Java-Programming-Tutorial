
class JavaTutorial27{


    public static void main(String[] args){

 	// TRY CATCH FINALLY

    try{
    	Scanner scanner = new Scanner(System.in);
    	int number;
    	System.out.println("Please enter an integer");
    	number = scanner.nextInt();
    }catch(InputMismatchException ex){
      System.out.println("You did not enter an integer");
    }finally{
      System.out.println("Mangyayare ako kahit walang error or may error");
    }



    }


}