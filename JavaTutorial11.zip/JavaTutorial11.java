import java.util.Scanner;

class JavaTutorial11{

	public static void main(String[] args){

     Scanner scan = new Scanner(System.in);

     int number;

     System.out.println("Please enter your favorite number");

     /*
      for other data types .nextDataType();
     for String it is .nextLine(); , reading the next line
	 */

     number = scan.nextInt();

     System.out.println("The number you've entered is "+number);

	} 
}