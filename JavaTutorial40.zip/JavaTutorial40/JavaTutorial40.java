import java.util.ArrayList;
import java.util.Collections;

class JavaTutorial40{


    public static void main(String[] args){
   
    //ArrayList declare
    //img source:https://www.geeksforgeeks.org/binary-search/

    ArrayList<String> words = new ArrayList<>();
    int find;
    int key="Chocolates";
    words.add("Hello");
    words.add("World");
    words.add("Gels");
    words.add("Chocolates");

    //sort natin muna
    Collections.sort(words,new StringComparator());

    find = Collections.binarySearch(words,key,new StringComparator());

    System.out.printf("String %s was %s found\n",key, find<0? "not":"");





    }


}