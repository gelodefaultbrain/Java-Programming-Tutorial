class JavaTutorial7{

	public static void main(String[] args){
		
     int x = 10;
     double r = (double) x;

     //(float)
     //System.out.println((double) x);
     System.out.println(r);

	} 
}