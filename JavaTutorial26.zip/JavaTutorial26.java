
class JavaTutorial26{

    static int x;

    public static void main(String[] args){

 	 /*
      functions in java
      return type
      parameters in java
      local, global scopes
 	 */

    // int result = getSum(10,20,30);

    //System.out.println(result);
    System.out.println(x);

	}


	 public static void sayHello(){
    	
      return x + y + z;

    	System.out.println(x);


	 }



}