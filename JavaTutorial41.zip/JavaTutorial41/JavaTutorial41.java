class JavaTutorial41{


    public static void main(String[] args){
   
 
    Hotdog hotdog1 = new Hotdog();
    hotdog1.sayFood();


    }


}