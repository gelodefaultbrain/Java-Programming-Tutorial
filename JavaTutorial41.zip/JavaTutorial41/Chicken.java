public class Chicken extends Food{
    /*
    extends Hotdog, making Chicken class like a grandchild of Food Class
	cause Hotdog class extends Food Class
	*/


}