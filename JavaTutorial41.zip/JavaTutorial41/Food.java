public class Food{

 public void sayFood(){
  	System.out.println("Food");
  }


}