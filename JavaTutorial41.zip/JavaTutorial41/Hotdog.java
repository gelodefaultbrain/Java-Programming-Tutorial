public class Hotdog extends Food{

@Override
public void sayFood(){
  	System.out.println("sayFood from Hotdog class itself");
  }


}