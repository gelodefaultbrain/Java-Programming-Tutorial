class JavaTutorial6{

	public static void main(String[] args){
		
     String name = "Gels";
     String des = "Handsome";

     String number = "1";
   
     int x = Integer.parseInt(number); //convert into integer
     double y = Double.parseDouble(number) //convert into double

     System.out.println(x);
     System.out.println(y);

	} 
}