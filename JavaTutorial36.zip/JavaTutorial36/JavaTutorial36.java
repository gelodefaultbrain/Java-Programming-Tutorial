import java.util.ArrayList;
import java.util.Collections;

class JavaTutorial36{


    public static void main(String[] args){
   
    //ArrayList declare

    ArrayList<Integer> numbers = new ArrayList<>();

    numbers.add(6);
    numbers.add(3);
    numbers.add(11);
    numbers.add(0);
    numbers.add(2);
    numbers.add(9);

    System.out.println("NOT SORTED!");

    for(Integer num : numbers)
    {
      System.out.println("Number "+num);
    }


    System.out.println("SORTED!");
    /*
    new IntComparator() kasi it's a class so kailangan natin 
    gumawa ng object from our IntComparator class
    */
    Collections.sort(numbers,new IntComparator()); //sorting happens

    for(Integer num1: numbers)
    {
      System.out.println("Number "+num1);
    }


    }


}