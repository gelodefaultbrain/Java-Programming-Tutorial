import java.util.Comparator;

public class IntComparator implements Comparator<Integer>{

  @Override
  public int compare(Integer a, Integer b){
    return a-b; 
    /*
    gusto mo to be in descending order?
    just change a-b to b-a
    */
  }

}