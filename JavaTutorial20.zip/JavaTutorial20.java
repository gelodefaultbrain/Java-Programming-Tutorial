
class JavaTutorial20{

     public static void main(String[] args){

 	 int[] array;
 	 array = new int[] {10,1,3,4,7,8};

 	 array[2] = 120;

 	 System.out.println(array[2]);
 	 System.out.println("Hello array "+array);

 	 /*
	 array[0] = 100;
	 array[1] = 200;
	 array[2] = 300;



 	 */

	} 
}