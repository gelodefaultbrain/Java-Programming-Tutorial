public class Dog{

   //Fields or Attributes , Katangian

   /*
   It's better for the attributes to be private
	pero pano natin ma-access yung attributes?
	Watch! on the tutorial about Getters & Setters (Java Tutorial #32)
  In the next tutorial!
  */
   private String breed;
   private String size;
   private int age;
   private String color;

   public Dog(){//Constructor

   }

   //Methods
   public void Eat(){
     System.out.println("Dog is Eating");
   }

    public void Sleep(){
     System.out.println("Dog is sleeping");
   }

    public void Sit(){
     System.out.println("Dog is sitting");
   }

    public void Run(){
     System.out.println("Dog is running");
   }


   //Getters and Setters

   //Setters
   public void setBreed(String _breed){
       this.breed = _breed;
   }

    public void setSize(String _size){
       this.size = _size;
   }


    public void setAge(int _age){
       this.age = _age;
   }


    public void setColor(String _color){
       this.color = _color;
   }



   //Getter

   public String getBreed(){
      return this.breed;
   }

   public String getSize(){
      return this.size;
   }


   public int getAge(){
      return this.age;
   }


   public String getColor(){
      return this.color;
   }











}