class JavaTutorial32{


    public static void main(String[] args){

    
    //Making an instance of an Object of type Dog
    Dog myDog = new Dog();
    myDog.setBreed("Askal");
    System.out.println(myDog.getBreed());

    Dog myDog1 = new Dog();
    myDog1.setAge(10);
    System.out.println(myDog1.getAge());



    }


}