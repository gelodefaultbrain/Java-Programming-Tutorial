
class JavaTutorial19{

     public static void main(String[] args){

 	 /*
     while loop

     vs

     do while loop
 	 */

     int x = 2;

 	 /*
      while(x == 20)
      {
	    System.out.println("Hello World");
      }
 	 */

      do
      {
      	System.out.println("Hello World");
      }while(x == 20);




	} 
}