public class Cat{

   //Attributes
   private String name;
   private String color;
   private int age;

   //Constructor
   public Cat(String _name, String _color, int _age){
       this.name = _name;
       this.color = _color;
       this.age = _age

   }



 //methods

 public void sayMeow(){
  System.out.println("Meow meow!");
 }

 public void sayHelloHooman(){
  System.out.println("Hello Hooman!");
 }

 
  //Getters and Setters

   //Getter

   public String getName(){
      return this.name;
   }

    public void setName(String _name){
       this.name = _name;
   }

   public String getColor(){
      return this.color;
   }

    public void setColor(String _color){
       this.color = _color;
   }


   public int getAge(){
      return this.age;
   }

    public void setAge(int _age){
       this.age = _age;
   }






}