class JavaTutorial33{


    public static void main(String[] args){
    
    /*
    Constructor is a block of code that initializes the newly created object.
 	A constructor resembles an instance method in java but it’s not a method as it doesn’t have a return type. 
	In short constructor and method are different(More on this at the end of this guide). 
	People often refer constructor as special type of method in Java.
    */

    Cat myCat = new Cat("Sponge","Orange",4);
    System.out.println("Name of cat is "+myCat.getName());

    myCat.setName("Hairy Baby");
    System.out.println("Name of cat is "+myCat.getName());


    }


}