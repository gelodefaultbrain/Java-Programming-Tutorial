import java.util.Comparator;

public class GradeComparator implements Comparator<Student>{

  @Override
  public int compare(Student g1, Student g2){
    return (int) ((g1.getGrade()*1000) - (g2.getGrade()*1000));
    /*
    gusto mo to be in descending order?
    just change ((g1.getGrade()*1000) - (g2.getGrade()*1000)); 
    to ((g2.getGrade()*1000) - (g1.getGrade()*1000));
    */
  }

}