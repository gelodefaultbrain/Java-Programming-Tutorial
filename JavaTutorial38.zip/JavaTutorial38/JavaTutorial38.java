import java.util.ArrayList;
import java.util.Collections;

class JavaTutorial38{


    public static void main(String[] args){
   
    //ArrayList declare

    ArrayList<Student> st = new ArrayList<>();

    st.add(new Student("Cardo",30,2.7));
    st.add(new Student("Onyok",6,3.2));
    st.add(new Student("Alyana",28,1.2));
    st.add(new Student("Ganda",22,1.6));
    st.add(new Student("Zombie",100,3.0));

    System.out.println("NOT SORTED");


    for(Student s: st)
    {
     System.out.println("Name "+s.getName() + "Grade: "+s.getGrade());
    }

    System.out.println("SORTED BU GRADE: ");
    Collections.sort(st,new GradeComparator());//sort

    for(Student j: st)
    {
        System.out.println("Name "+j.getName()+ "Grade: "+j.getGrade());
    }

    





    }


}