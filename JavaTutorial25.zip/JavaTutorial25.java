
class JavaTutorial25{

    public static void main(String[] args){

 	 /*
      functions in java
      return type
      parameters in java
 	 */

      sayHello(); // function call

	}


	 public static void sayHello(){
    	System.out.println("Hello World");

    	int a = 2;
    	int b = 1;
    	int c = a + b;

    	System.out.println(c);


	 }



}