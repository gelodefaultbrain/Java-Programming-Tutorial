class JavaTutorial30{


    public static void main(String[] args){

    /*

    Math.max(x,y);
    Math.min(x,y);
    Math.sqrt(x);
    Math.pow(x,y); //x^y
    
    Math.PI;
    Math.E;

    */
    

    System.out.println(Math.max(50,7));
    System.out.println(Math.min(50,7));

    System.out.println(Math.sqrt(4));
    System.out.println(Math.pow(3,3));

    System.out.println(Math.PI);
    System.out.println(Math.E);



    }


}