class JavaTutorial8{

	public static void main(String[] args){
	
	int x = 2;
	int y = 10;

	/*
    x++ and x+=1 is just the same as  x= x+1;
    Same with other operators like - , / , *
	*/

	// you can store the result in a variable with its correct data type
	System.out.println(x + y);

	} 
}