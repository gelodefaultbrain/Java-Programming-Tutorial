
class JavaTutorial22{

     public static void main(String[] args){

 	 
 	 String word = "Hello";

 	 System.out.println(word.charAt(1));



	} 
}