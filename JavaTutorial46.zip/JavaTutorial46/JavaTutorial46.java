class JavaTutorial46{


    public static void main(String[] args){
   
 
    Laptop lenov = new Lenovo();
    lenov.click();

    Laptop asu = new Asus();
    asu.click();
    

    }


}