public class Lenovo implements Laptop{
  
   @Override
   public void click(){
  	System.out.println("Clicking Lenovo Class");
  }

   @Override
   public void open(){
  	System.out.println("Open Lenovo Class");
  }


   @Override
   public void close(){
  	System.out.println("Close Lenovo Class");
  }


   @Override
   public void sleep(){
  	System.out.println("Sleep Lenovo Class");
  }



}