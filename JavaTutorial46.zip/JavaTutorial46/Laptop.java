public interface Laptop{
	public void click();
	public void open();
	public void close();
	public void sleep();
}