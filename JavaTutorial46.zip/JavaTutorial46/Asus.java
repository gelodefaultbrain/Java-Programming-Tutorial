public class Asus implements Laptop{
  
  @Override
   public void click(){
  	System.out.println("Clicking Asus Class");
  }

   @Override
   public void open(){
  	System.out.println("Open Asus Class");
  }


   @Override
   public void close(){
  	System.out.println("Close Asus Class");
  }


   @Override
   public void sleep(){
  	System.out.println("sleep Asus Class");
  }
  
}