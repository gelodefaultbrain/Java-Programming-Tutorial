import java.util.Scanner;

class JavaTutorial12{

	public static void main(String[] args){

     Scanner scan = new Scanner(System.in);

     System.out.println("Enter number");

     int number = scan.nextInt();

     if(number > 10)
     {
     	System.out.println("Number is greater than 10");
     }else if(number < 10)
     {
     	System.out.println("Number is less than 10");
     }else if(number == 10)
     {
     	System.out.println("Number is equal to 10");
     }else
     {
     	System.out.println("Lahat ng previous conditions ay false");
     	System.out.println("Hello else");
     }



	} 
}