import java.util.ArrayList;
import java.util.Collections;

class JavaTutorial39{


    public static void main(String[] args){
   
    //ArrayList declare
    //img source:https://www.geeksforgeeks.org/binary-search/

    ArrayList<Integer> numbers = new ArrayList<>();
    int find;
    int key=100;
    numbers.add(3);
    numbers.add(0);
    numbers.add(15);
    numbers.add(10);
    numbers.add(2);
    numbers.add(7);
    numbers.add(44);

    //sort natin muna

    Collections.sort(numbers,new IntegerComparator());

    find = Collections.binarySearch(numbers,key,new IntegerComparator());

    System.out.printf("Number %d was %s found\n",key, find<0? "not":"");





    }


}