import java.util.ArrayList;

class JavaTutorial35{


    public static void main(String[] args){
   
    //ArrayList declare

    ArrayList<Student> st = new ArrayList<>();

    st.add(new Student("Cardo",30,1.2));
    st.add(new Student("Alyana",29,3.0));
    st.add(new Student("Alakdan",34,2.3));
    st.add(new Student("Onyok",7,1.0));

    //st.remove(2);

    //destination is also the INDEX, sorry i forgot to mention it HAHA
    st.set(); //set(destination,soruce)

    //easy way
    for(Student s: st)
    {
       //Iteration
       System.out.printf("Student %s\n",s);
    }


    //hard way
    /*
    int i;
    System.out.println();
    for(i=0; i < st.size(); i++)
    {
      System.out.println("Student ",st.get(i));
    }
    */



    }


}