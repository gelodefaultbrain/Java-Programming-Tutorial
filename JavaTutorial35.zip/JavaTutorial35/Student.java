public class Student{

   //Attributes
   private String name;
   private int age;
   private double grade;

   //Constructor
   public Student(String _name, int _age, double _grade){
       this.name = _name;
       this.age = _age;
       this.grade = _grade;

   }



 //methods

 public void sayHello(){
  System.out.println("Hello");
 }

 @Override
 public String toString(){
 	return String.format("Student %s %d %f",this.name,this.age,this.grade);
 }

 
  //Getters and Setters

   //Getter

   public String getName(){
      return this.name;
   }

    public void setName(String _name){
       this.name = _name;
   }

   public double getGrade(){
      return this.grade;
   }

    public void setGrade(double _grade){
       this.grade = _grade;
   }


   public int getAge(){
      return this.age;
   }

    public void setAge(int _age){
       this.age = _age;
   }






}