import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

class JavaTutorial28{


    public static void main(String[] args){

 	File myfile = new File("example.txt");

    try{
      PrintWriter pw = new PrintWriter(myfile);

      int number = 100;
      pw.println("Hello World " + 100);
      pw.println("I am handsome");
      pw.println("Hello File");

      pw.close();

    }catch(IOException ex){
      System.out.println("Error %s ",ex);
    }





    }


}