import java.util.ArrayList;

class JavaTutorial34{


    public static void main(String[] args){

 
    //Dynamic Array

    //ArrayList declare

    ArrayList<Integer> age = new ArrayList<>();

    age.add(19);//index 0
    age.add(20);//index 1
    age.add(21);//index 2
    age.add(22);//index 3
    age.add(23);//index 4
    age.add(24);//index 5

    age.remove(1);

    int i;

    for(i=0; i < age.size(); i++)
    {
       System.out.println("Index "+i +"equals "+age.get(i));
    }





    }


}