
class JavaTutorial24{

     public static void main(String[] args){

 	 
 	 int[][] array ={
      {4,1,3,7,9},
      {6,5,8,11,2},
      {12,14,17,20,0}
 	 };

     int row, column;

     for(row =0; row < 3; row++)
     {
     	for(column =0; column < 5; column++)
     	{
     		System.out.println(array[row][column] + " ");
     	}

     	System.out.println();

     }



	} 
}