import java.util.Scanner;
class JavaTutorial16{

	public static void main(String[] args){

    Scanner scanner = new Scanner(System.in);

    String name1 = "Alice";

    String input;

    System.out.println("Please enter your Name");
    input = scanner.nextLine();

    if(input.equals(name1))
    {
        System.out.println("Hello Alice");
    }else
    {
        System.out.println("Who are you");
    }


	} 
}