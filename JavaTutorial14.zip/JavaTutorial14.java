class JavaTutorial14{

	public static void main(String[] args){

     // <= , >= , !=

     if(x <= 10) // >=
     {
       System.out.println("True");
     }else
     {
       System.out.println("False");
     }


	} 
}