
class JavaTutorial17{

	public static void main(String[] args){

  
    int month_num = 100;

    /*
    You can do in char just change the case
    Example
    case 'a':
    	System.out.println("January");
    break;

    */
    char x = 'a';

    switch(month_num)
    {
    	case 1:
    		System.out.println("January");
    	break;

    	case 2:
    		System.out.println("February");
    	break;

    	case 3:
    		System.out.println("March");
    	break;

    	case 4:
    		System.out.println("April");
    	break;

    	default:
    		System.out.println("INVALID INPUT");
    	break;


    }


	} 
}