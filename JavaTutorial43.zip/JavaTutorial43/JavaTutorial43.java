class JavaTutorial43{


    public static void main(String[] args){
   
 
    Chicken chicken1 = new Chicken(10,"Chicken baby");

    chicken1.justPrint();

    }


}