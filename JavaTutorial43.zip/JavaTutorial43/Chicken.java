public class Chicken extends Food{
  
   private int age;
   private String name;
   
   public Chicken(int _age, String _name){
   	 super(100, "Chicken Little");//(_age,_name)
     this.age = _age;
     this.name = _name;
   }
 
 public void justPrint(){

  System.out.println("Chicken age "+this.age);
  System.out.println("Chicken name "+this.name);

  System.out.println("Food age "+super.getAge());
  System.out.println("Food name "+super.getName());




 }

}