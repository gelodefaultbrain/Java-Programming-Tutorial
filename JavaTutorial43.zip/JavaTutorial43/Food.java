public class Food{

	private int age;
	private String name;


	public Food(int age1, String name1){
		this.age = age1;
		this.name = name1;
	}



    public int getAge(){
    	return this.age;
    }

    public void setAge(int age){
       this.age = age;
    }


    public String getName(){
    	return this.name;
    }


    public void setName(String name){
       this.name = name;
    }


}