public class Chicken extends Food{

   
   public void saySomething(){
   	super.saySomething(); //super means yung parent class
  	System.out.println("Saying from Food class");
  	super.sayFood();
  }


}