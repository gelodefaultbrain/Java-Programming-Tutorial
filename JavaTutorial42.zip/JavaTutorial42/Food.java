public class Food{

 public void saySomething(){
  	System.out.println("Saying from Food class");
  }


   public void sayFood(){
  	System.out.println("Saying from Food class FOOD!");
  }


}