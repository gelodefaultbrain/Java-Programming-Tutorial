class JavaTutorial42{


    public static void main(String[] args){
   
 
    Chicken chicken1 = new Chicken();
    chicken1.saySomething();


    }


}