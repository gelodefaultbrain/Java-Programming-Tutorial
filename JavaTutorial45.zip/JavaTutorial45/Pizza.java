public class Pizza extends Food{
  
   @Override
   public void saySomething(){
  	System.out.println("Hello I am a pizza");
  }

}