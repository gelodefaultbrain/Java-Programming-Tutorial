class JavaTutorial45{


    public static void main(String[] args){
   
 
     Food tomato1 = new Tomato();
     tomato1.saySomething();

     Food pizza1 = new Pizza();
     pizza1.saySomething();
    

    }


}