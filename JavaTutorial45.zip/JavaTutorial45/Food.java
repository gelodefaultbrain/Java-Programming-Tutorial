abstract public class Food{

 public abstract void saySomething();

}