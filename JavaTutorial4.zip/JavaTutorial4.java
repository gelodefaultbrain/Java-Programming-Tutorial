class JavaTutorial4{

	public static void main(String[] args){
		/*
          int - 100
          char -'A'
          boolean - ture , false
		  float - 1.1234567 #hanggang 7 digits lang after decimal point
		  double - 13.123456789012345 #hanggang 15 digits lang after decimal point
		  long - 123456789101112

		*/
   
      int number = 100;
      char letter = 'A';
      boolean condition = true;
      double dl = 3.14;
      float fl = 1.2f; //put f to let java know na float yan cause in default numbers with decimal places are considered double in java
      long l = 12345678910L;


      System.out.println("Number is "+number);
      System.out.println("Letter is "+letter + "condition is "+condition);
      System.out.println("Double is "+dl);
      System.out.println("Float is "+fl);
      System.out.println("Long is "+l);
 

	} 
}