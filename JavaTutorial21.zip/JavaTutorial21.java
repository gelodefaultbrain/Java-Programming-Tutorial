
class JavaTutorial21{

     public static void main(String[] args){

 	 float[] array;
 	 array = new float[] {11,3,4,6,9};

 	 int i;

 	 for(i=0; i < array.length; i++)
 	 {
        System.out.println(array[i]);
 	 }




	} 
}